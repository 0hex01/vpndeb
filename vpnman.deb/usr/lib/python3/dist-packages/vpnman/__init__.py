from .vpnman import VPNManager

__version__ = '1.0.0'