#!/usr/bin/env python3
from .vpnman import VPNManager

def main():
    vpn_manager = VPNManager()
    vpn_manager.run()

if __name__ == '__main__':
    main()
