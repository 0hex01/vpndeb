#!/bin/bash

# This script must be run as root or a specified user on the local device only
AUTHORIZED_USER="user"  # Replace with the actual username allowed to run the script
VPN_DIR="./conconfigs/ovpn"
USERNAME="ta6nw0QWMw0lxZd3"
PASSWORD="Q31Lr3913wfEMLKA3U9vw9f4VMLb18bw"

# Function to restrict access to physical, local execution by root or the specified user
restrict_access() {
    # Check if the script is being run remotely by checking SSH environment
    if [ -n "$SSH_CONNECTION" ]; then
        echo "This script cannot be run remotely. Access denied."
        exit 1
    fi

    # Check if the current user is authorized
    if [[ $EUID -ne 0 && $USER != "$AUTHORIZED_USER" ]]; then
        echo "Access denied. Only $AUTHORIZED_USER or root can run this script."
        exit 1
    fi
}

# Run the restrict access function
restrict_access

# Function to connect to a random VPN file
connect_vpn() {
    # Pick a random .ovpn file from the VPN directory
    VPN_FILE=$(find "$VPN_DIR" -type f -name "*.ovpn" | shuf -n 1)
    
    # Create a temporary credentials file
    CREDENTIALS_FILE=$(mktemp)
    echo -e "$USERNAME\n$PASSWORD" > "$CREDENTIALS_FILE"
    chmod 600 "$CREDENTIALS_FILE"

    # Run OpenVPN in the background with the temporary credentials file
    sudo openvpn --config "$VPN_FILE" --auth-user-pass "$CREDENTIALS_FILE" &
    VPN_PID=$!

    # Clean up the temporary credentials file
    rm -f "$CREDENTIALS_FILE"
}

# Loop to switch VPN connections at random intervals
while true; do
    # Connect to a VPN
    connect_vpn

    # Wait for a random interval between 15 and 60 minutes (900 to 3600 seconds)
    INTERVAL=$((RANDOM % 2700 + 900))
    sleep "$INTERVAL"

    # Kill the current VPN connection
    sudo kill "$VPN_PID"
done
