#!/bin/bash

# This script must be run as root
if [[ $EUID -ne 0 ]]; then
   echo "Please run as root"
   exit 1
fi

VPN_DIR="/home/user/vpn"
USERNAME="ta6nw0QWMw0lxZd3"
PASSWORD="Q31Lr3913wfEMLKA3U9vw9f4VMLb18bw"

# Pick a random .ovpn file from the VPN directory
VPN_FILE=$(find "$VPN_DIR" -type f -name "*.ovpn" | shuf -n 1)

# Create a temporary credentials file
CREDENTIALS_FILE=$(mktemp)
echo -e "$USERNAME\n$PASSWORD" > "$CREDENTIALS_FILE"
chmod 600 "$CREDENTIALS_FILE"

# Run OpenVPN with the temporary credentials file
sudo openvpn --config "$VPN_FILE" --auth-user-pass "$CREDENTIALS_FILE"

# Clean up: Remove the temporary credentials file after OpenVPN exits
rm -f "$CREDENTIALS_FILE"
